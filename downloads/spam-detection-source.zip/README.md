# Spam Detection using Machine Learning

Final-year B.E. project by Sakshi Bhusari — a Django web app that classifies a
message as **Spam** or **Ham (not spam)** using a Naive Bayes classifier
trained with scikit-learn.

## How it works

- `emails.csv` — labeled dataset of messages used for training.
- The text is vectorized with `CountVectorizer` (bag-of-words).
- A `MultinomialNB` (Naive Bayes) model is trained on an 80/20 train-test split.
- A simple Django form takes a message from the user and returns the
  predicted label.

## Tech stack

Python · Django · scikit-learn · pandas · numpy

## Running it locally

```bash
cd spamDetection
python -m venv myenv
source myenv/bin/activate      # on Windows: myenv\Scripts\activate
pip install -r ../requirements.txt
python manage.py migrate
python manage.py runserver
```

Then open `http://127.0.0.1:8000/` in your browser.

## Project structure

```
spamDetection/        Django project
  spamDetection/       settings, urls, wsgi/asgi
  detector/            the app: form, view, prediction logic, template
emails.csv            training dataset
requirements.txt      Python dependencies
```
